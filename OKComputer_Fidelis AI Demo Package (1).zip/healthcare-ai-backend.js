// Healthcare AI Backend - Production Ready
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { OpenAI } = require('openai');
const { Pool } = require('pg');
const Redis = require('redis');
const winston = require('winston');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

// Production configuration
const config = {
    openaiApiKey: process.env.OPENAI_API_KEY,
    databaseUrl: process.env.DATABASE_URL,
    redisUrl: process.env.REDIS_URL,
    jwtSecret: process.env.JWT_SECRET,
    port: process.env.PORT || 3000,
    environment: process.env.NODE_ENV || 'development'
};

// Initialize services
const openai = new OpenAI({ apiKey: config.openaiApiKey });
const redis = Redis.createClient({ url: config.redisUrl });
const pool = new Pool({ connectionString: config.databaseUrl });

// Logger configuration
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/combined.log' }),
        new winston.transports.Console()
    ]
});

const app = express();

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "https://api.openai.com"]
        }
    }
}));

app.use(cors({
    origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
    credentials: true
}));

app.use(express.json({ limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.'
});

app.use('/api/', limiter);

// Healthcare context for AI
const healthcareContext = {
    systemPrompt: `You are Fidelis AI Navigator, a helpful healthcare assistant for Fidelis Care members in New York. You specialize in:
    
    1. MEDICAID REDETERMINATION: Help members navigate complex renewal processes, identify missing documents, and schedule appointments
    2. BILLING ISSUES: Detect duplicate charges, explain benefits, and guide through appeals
    3. PROVIDER SEARCH: Find in-network doctors, specialists, and facilities with language preferences
    4. PHARMACY SUPPORT: Prior authorization assistance, medication coverage, and refill reminders
    5. BENEFITS VERIFICATION: Real-time eligibility checks and cost estimation
    
    Always be empathetic, accurate, and efficient. If you cannot resolve an issue immediately, escalate to a human agent.
    
    Current date: ${new Date().toISOString()}
    Service area: New York State (all counties)
    Primary languages: English, Spanish, Chinese, Russian, Arabic, Haitian Creole, Bengali, Korean, Yiddish`,
    
    scenarios: {
        billing: {
            keywords: ['duplicate', 'billing', 'charge', 'error', 'payment'],
            actions: ['detect_duplicate', 'explain_benefits', 'initiate_appeal']
        },
        redetermination: {
            keywords: ['renewal', 'redetermination', 'medicaid', 'documents', 'eligibility'],
            actions: ['check_status', 'identify_missing_docs', 'schedule_appointment']
        },
        pharmacy: {
            keywords: ['medication', 'prescription', 'prior authorization', 'pharmacy'],
            actions: ['check_coverage', ' expedite_auth', 'find_alternative']
        },
        provider: {
            keywords: ['doctor', 'dentist', 'specialist', 'provider', 'appointment'],
            actions: ['search_network', 'check_availability', 'schedule_appointment']
        }
    }
};

// Database schema initialization
async function initializeDatabase() {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS ai_conversations (
                id SERIAL PRIMARY KEY,
                session_id VARCHAR(100) NOT NULL,
                member_id VARCHAR(50),
                scenario VARCHAR(50),
                user_message TEXT NOT NULL,
                ai_response TEXT NOT NULL,
                context JSONB,
                resolved BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS member_eligibility (
                member_id VARCHAR(50) PRIMARY KEY,
                is_active BOOLEAN,
                plan_type VARCHAR(100),
                effective_date DATE,
                expiration_date DATE,
                copay_amount DECIMAL(10,2),
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS providers (
                id SERIAL PRIMARY KEY,
                npi VARCHAR(20) UNIQUE,
                name VARCHAR(200),
                specialty VARCHAR(100),
                languages TEXT[],
                address JSONB,
                phone VARCHAR(20),
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS analytics_events (
                id SERIAL PRIMARY KEY,
                event_type VARCHAR(50),
                session_id VARCHAR(100),
                member_id VARCHAR(50),
                scenario VARCHAR(50),
                metadata JSONB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        logger.info('Database initialized successfully');
    } catch (error) {
        logger.error('Database initialization failed:', error);
        throw error;
    }
}

// Healthcare AI service
class HealthcareAIService {
    async processMessage(message, memberId, scenario) {
        try {
            // Detect scenario if not provided
            if (!scenario) {
                scenario = this.detectScenario(message);
            }

            // Get conversation history for context
            const conversationHistory = await this.getConversationHistory(memberId);
            
            // Prepare messages for OpenAI
            const messages = [
                { role: 'system', content: healthcareContext.systemPrompt },
                ...conversationHistory.slice(-5), // Last 5 messages for context
                { role: 'user', content: message }
            ];

            // Call OpenAI API
            const completion = await openai.chat.completions.create({
                model: 'gpt-4-turbo-preview',
                messages: messages,
                max_tokens: 500,
                temperature: 0.3,
                presence_penalty: 0.1,
                frequency_penalty: 0.1
            });

            const aiResponse = completion.choices[0].message.content;

            // Log conversation for analytics
            await this.logConversation(memberId, scenario, message, aiResponse);

            // Track analytics event
            await this.trackAnalyticsEvent('ai_interaction', {
                memberId,
                scenario,
                messageLength: message.length,
                responseLength: aiResponse.length,
                tokensUsed: completion.usage.total_tokens
            });

            return {
                response: aiResponse,
                scenario: scenario,
                confidence: 0.95, // Could be calculated based on response quality
                followUpRequired: this.isFollowUpRequired(aiResponse)
            };

        } catch (error) {
            logger.error('AI processing error:', error);
            throw new Error('AI processing failed');
        }
    }

    detectScenario(message) {
        const lowerMessage = message.toLowerCase();
        
        for (const [scenario, config] of Object.entries(healthcareContext.scenarios)) {
            if (config.keywords.some(keyword => lowerMessage.includes(keyword))) {
                return scenario;
            }
        }
        
        return 'general';
    }

    async getConversationHistory(memberId) {
        try {
            const result = await pool.query(
                'SELECT user_message, ai_response FROM ai_conversations WHERE member_id = $1 ORDER BY created_at DESC LIMIT 5',
                [memberId]
            );
            
            return result.rows.reverse().map(row => [
                { role: 'user', content: row.user_message },
                { role: 'assistant', content: row.ai_response }
            ]).flat();
        } catch (error) {
            logger.error('Error fetching conversation history:', error);
            return [];
        }
    }

    async logConversation(memberId, scenario, userMessage, aiResponse) {
        try {
            await pool.query(
                'INSERT INTO ai_conversations (session_id, member_id, scenario, user_message, ai_response) VALUES ($1, $2, $3, $4, $5)',
                [`session_${Date.now()}`, memberId, scenario, userMessage, aiResponse]
            );
        } catch (error) {
            logger.error('Error logging conversation:', error);
        }
    }

    async trackAnalyticsEvent(eventType, data) {
        try {
            await pool.query(
                'INSERT INTO analytics_events (event_type, session_id, member_id, scenario, metadata) VALUES ($1, $2, $3, $4, $5)',
                [eventType, data.sessionId || 'unknown', data.memberId || 'unknown', data.scenario || 'unknown', JSON.stringify(data)]
            );
        } catch (error) {
logger.error('Analytics tracking error:', error);
        }
    }

    isFollowUpRequired(response) {
        const followUpIndicators = ['I need more information', 'please provide', 'contact your', 'speak with a human'];
        return followUpIndicators.some(indicator => response.toLowerCase().includes(indicator));
    }
}

// Member services
class MemberService {
    async checkEligibility(memberId) {
        try {
            // In production, this would call Fidelis Care's actual API
            const result = await pool.query(
                'SELECT * FROM member_eligibility WHERE member_id = $1',
                [memberId]
            );
            
            if (result.rows.length === 0) {
                // Mock response for demo
                return {
                    memberId,
                    isActive: true,
                    planType: 'Medicaid Managed Care',
                    effectiveDate: '2024-01-01',
                    expirationDate: '2024-12-31',
                    copayAmount: 0.00
                };
            }
            
            return result.rows[0];
        } catch (error) {
            logger.error('Eligibility check error:', error);
            throw error;
        }
    }

    async findProvider(specialty, language, location) {
        try {
            const result = await pool.query(
                'SELECT * FROM providers WHERE specialty ILIKE $1 AND languages @> ARRAY[$2] AND is_active = true LIMIT 10',
                [`%${specialty}%`, language]
            );
            
            if (result.rows.length === 0) {
                // Mock response for demo
                return [
                    {
                        name: 'Dr. Maria Gonzalez',
                        specialty: 'Family Medicine',
                        languages: ['English', 'Spanish'],
                        address: { street: '123 Bronx Ave', city: 'Bronx', state: 'NY', zip: '10451' },
                        phone: '(718) 555-0123',
                        isAccepting: true
                    }
                ];
            }
            
            return result.rows;
        } catch (error) {
            logger.error('Provider search error:', error);
            throw error;
        }
    }
}

// Initialize services
const aiService = new HealthcareAIService();
const memberService = new MemberService();

// API Routes
app.post('/api/ai/chat', async (req, res) => {
    try {
        const { message, memberId, scenario } = req.body;
        
        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        const result = await aiService.processMessage(message, memberId, scenario);
        
        res.json({
            success: true,
            data: result
        });
        
    } catch (error) {
        logger.error('Chat API error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

app.get('/api/members/:memberId/eligibility', async (req, res) => {
    try {
        const { memberId } = req.params;
        const eligibility = await memberService.checkEligibility(memberId);
        
        res.json({
            success: true,
            data: eligibility
        });
        
    } catch (error) {
        logger.error('Eligibility API error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

app.get('/api/providers', async (req, res) => {
    try {
        const { specialty, language, location } = req.query;
        const providers = await memberService.findProvider(specialty, language, location);
        
        res.json({
            success: true,
            data: providers
        });
        
    } catch (error) {
        logger.error('Provider search API error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// Analytics endpoint
app.get('/api/analytics', async (req, res) => {
    try {
        const { days = 30 } = req.query;
        
        const conversations = await pool.query(
            'SELECT COUNT(*) as total_conversations, scenario, AVG(EXTRACT(EPOCH FROM (updated_at - created_at))) as avg_duration FROM ai_conversations WHERE created_at > NOW() - INTERVAL \$1 days GROUP BY scenario',
            [days]
        );
        
        const events = await pool.query(
            'SELECT event_type, COUNT(*) as count FROM analytics_events WHERE created_at > NOW() - INTERVAL \$1 days GROUP BY event_type',
            [days]
        );
        
        res.json({
            success: true,
            data: {
                conversations: conversations.rows,
                events: events.rows,
                period: `${days} days`
            }
        });
        
    } catch (error) {
        logger.error('Analytics API error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    logger.error('Unhandled error:', error);
    res.status(500).json({
        success: false,
        error: 'Internal server error'
    });
});

// Start server
async function startServer() {
    try {
        await initializeDatabase();
        await redis.connect();
        
        app.listen(config.port, () => {
            logger.info(`Healthcare AI server running on port ${config.port}`);
            logger.info(`Environment: ${config.environment}`);
        });
        
    } catch (error) {
        logger.error('Failed to start server:', error);
        process.exit(1);
    }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
    logger.info('SIGTERM received, shutting down gracefully');
    await pool.end();
    await redis.quit();
    process.exit(0);
});

startServer();

module.exports = app;