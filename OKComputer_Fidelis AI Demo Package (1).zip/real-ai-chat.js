// Real AI Chat Frontend - Production Ready
class RealHealthcareAI {
    constructor() {
        this.apiEndpoint = '/api/ai/chat';
        this.memberId = this.generateMemberId();
        this.sessionId = this.generateSessionId();
        this.conversationHistory = [];
        this.isTyping = false;
        
        this.initializeEventListeners();
        this.loadConversationHistory();
    }

    generateMemberId() {
        // In production, this would come from authentication
        return 'MEM_' + Math.random().toString(36).substr(2, 9);
    }

    generateSessionId() {
        return 'SESSION_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    initializeEventListeners() {
        const userInput = document.getElementById('userInput');
        const sendButton = document.querySelector('.demo-input button');
        const scenarioSelect = document.getElementById('scenarioSelect');

        if (userInput) {
            userInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !this.isTyping) {
                    this.sendMessage();
                }
            });
        }

        if (sendButton) {
            sendButton.addEventListener('click', () => {
                if (!this.isTyping) {
                    this.sendMessage();
                }
            });
        }

        if (scenarioSelect) {
            scenarioSelect.addEventListener('change', () => {
                this.changeScenario();
            });
        }
    }

    async sendMessage() {
        const userInput = document.getElementById('userInput');
        const message = userInput.value.trim();

        if (!message || this.isTyping) return;

        // Add user message to chat
        this.addUserMessage(message);
        userInput.value = '';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            // Call real AI API
            const response = await this.callAIAPI(message);
            
            // Hide typing indicator and show AI response
            this.hideTypingIndicator();
            this.addAIMessage(response.data.response, response.data.scenario);

            // Update conversation history
            this.conversationHistory.push({
                user: message,
                ai: response.data.response,
                timestamp: new Date().toISOString(),
                scenario: response.data.scenario
            });

            // Save to local storage
            this.saveConversationHistory();

            // Handle follow-up if needed
            if (response.data.followUpRequired) {
                this.showFollowUpOptions(response.data.scenario);
            }

        } catch (error) {
            console.error('AI API error:', error);
            this.hideTypingIndicator();
            this.addAIMessage("I apologize, but I'm having trouble processing your request right now. Please try again or contact customer service.");
        }
    }

    async callAIAPI(message) {
        const scenario = document.getElementById('scenarioSelect')?.value || 'general';
        
        const response = await fetch(this.apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.getAuthToken()}`
            },
            body: JSON.stringify({
                message: message,
                memberId: this.memberId,
                scenario: scenario,
                sessionId: this.sessionId
            })
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }

        return await response.json();
    }

    getAuthToken() {
        // In production, this would come from authentication service
        return localStorage.getItem('authToken') || 'demo_token';
    }

    addUserMessage(message) {
        const chatContainer = document.getElementById('chatContainer');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'user-message message';
        messageDiv.textContent = message;
        
        chatContainer.appendChild(messageDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    addAIMessage(message, scenario = null) {
        const chatContainer = document.getElementById('chatContainer');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-message message';
        
        // Add scenario badge if available
        if (scenario) {
            const badge = document.createElement('div');
            badge.className = 'scenario-badge';
            badge.textContent = this.getScenarioName(scenario);
            messageDiv.appendChild(badge);
        }
        
        const messageText = document.createElement('div');
        messageText.textContent = message;
        messageDiv.appendChild(messageText);
        
        chatContainer.appendChild(messageDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;

        // Add typing animation
        this.animateMessage(messageDiv);
    }

    getScenarioName(scenario) {
        const names = {
            billing: 'Billing Support',
            redetermination: 'Medicaid Renewal',
            pharmacy: 'Pharmacy Help',
            provider: 'Provider Search',
            general: 'General Help'
        };
        return names[scenario] || 'Healthcare AI';
    }

    showTypingIndicator() {
        this.isTyping = true;
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.style.display = 'block';
            indicator.textContent = 'AI is analyzing your request...';
        }
    }

    hideTypingIndicator() {
        this.isTyping = false;
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.style.display = 'none';
        }
    }

    animateMessage(messageElement) {
        // Add typing animation effect
        messageElement.style.opacity = '0';
        messageElement.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            messageElement.style.transition = 'all 0.3s ease';
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
        }, 100);
    }

    showFollowUpOptions(scenario) {
        const chatContainer = document.getElementById('chatContainer');
        const followUpDiv = document.createElement('div');
        followUpDiv.className = 'follow-up-options';
        
        const options = this.getFollowUpOptions(scenario);
        
        options.forEach(option => {
            const button = document.createElement('button');
            button.className = 'follow-up-btn';
            button.textContent = option.text;
            button.onclick = () => {
                document.getElementById('userInput').value = option.prompt;
                this.sendMessage();
            };
            
            followUpDiv.appendChild(button);
        });
        
        chatContainer.appendChild(followUpDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    getFollowUpOptions(scenario) {
        const options = {
            billing: [
                { text: 'Check claim status', prompt: 'Check the status of my claim' },
                { text: 'Dispute charge', prompt: 'I want to dispute a charge' },
                { text: 'Explain benefits', prompt: 'Explain my benefits' }
            ],
            redetermination: [
                { text: 'Check renewal status', prompt: 'Check my renewal status' },
                { text: 'Missing documents', prompt: 'What documents do I need?' },
                { text: 'Schedule appointment', prompt: 'Schedule an appointment' }
            ],
            pharmacy: [
                { text: 'Check coverage', prompt: 'Is my medication covered?' },
                { text: 'Prior authorization', prompt: 'I need prior authorization' },
                { text: 'Find pharmacy', prompt: 'Find a pharmacy near me' }
            ],
            provider: [
                { text: 'Find doctor', prompt: 'Find me a doctor' },
                { text: 'Check availability', prompt: 'Check doctor availability' },
                { text: 'Book appointment', prompt: 'Book an appointment' }
            ]
        };
        
        return options[scenario] || [];
    }

    changeScenario() {
        const scenario = document.getElementById('scenarioSelect').value;
        this.addAIMessage(`I've switched to ${this.getScenarioName(scenario)} mode. How can I help you with ${scenario} issues?`);
    }

    saveConversationHistory() {
        try {
            localStorage.setItem(`healthcare_ai_history_${this.memberId}`, JSON.stringify(this.conversationHistory));
        } catch (error) {
            console.error('Error saving conversation history:', error);
        }
    }

    loadConversationHistory() {
        try {
            const saved = localStorage.getItem(`healthcare_ai_history_${this.memberId}`);
            if (saved) {
                this.conversationHistory = JSON.parse(saved);
            }
        } catch (error) {
            console.error('Error loading conversation history:', error);
        }
    }

    // Real-time features
    async checkMemberStatus() {
        try {
            const response = await fetch(`/api/members/${this.memberId}/eligibility`);
            const data = await response.json();
            
            if (data.success) {
                this.updateMemberStatus(data.data);
            }
        } catch (error) {
            console.error('Error checking member status:', error);
        }
    }

    updateMemberStatus(eligibility) {
        // Update UI with real member status
        const statusElement = document.getElementById('memberStatus');
        if (statusElement) {
            statusElement.innerHTML = `
                <div class="member-status">
                    <span class="status-indicator ${eligibility.isActive ? 'active' : 'inactive'}"></span>
                    <span>Member Status: ${eligibility.isActive ? 'Active' : 'Inactive'}</span>
                    <span>Plan: ${eligibility.planType}</span>
                </div>
            `;
        }
    }

    // Voice input (future enhancement)
    async startVoiceInput() {
        if ('webkitSpeechRecognition' in window) {
            const recognition = new webkitSpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';

            recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                document.getElementById('userInput').value = transcript;
            };

            recognition.start();
        } else {
            this.addAIMessage("Voice input is not supported in your browser. Please type your message.");
        }
    }

    // Analytics tracking
    trackEvent(eventType, data) {
        // Send analytics to backend
        fetch('/api/analytics', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                eventType,
                sessionId: this.sessionId,
                memberId: this.memberId,
                ...data
            })
        }).catch(error => console.error('Analytics tracking error:', error));
    }
}

// Initialize real AI chat when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.healthcareAI = new RealHealthcareAI();
    
    // Add CSS for real-time features
    const style = document.createElement('style');
    style.textContent = `
        .scenario-badge {
            background: #1b4d4d;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 10px;
            margin-bottom: 8px;
            display: inline-block;
        }
        
        .follow-up-options {
            margin: 16px 0;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .follow-up-btn {
            background: #f3f4f6;
            border: 1px solid #d1d5db;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .follow-up-btn:hover {
            background: #1b4d4d;
            color: white;
            border-color: #1b4d4d;
        }
        
        .member-status {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 8px;
            font-size: 12px;
            margin-bottom: 16px;
        }
        
        .status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #22c55e;
        }
        
        .status-indicator.inactive {
            background: #ef4444;
        }
        
        .typing-indicator {
            display: none;
            padding: 12px 16px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            margin-bottom: 12px;
            font-style: italic;
            color: #6b7280;
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
    `;
    document.head.appendChild(style);
});