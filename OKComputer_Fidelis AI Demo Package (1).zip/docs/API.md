# Fidelis Healthcare AI - API Documentation

## 🔗 **Base URL**
```
https://bs734nbc735og.ok.kimi.link/api
```

## 📋 **Authentication**

Most endpoints require JWT authentication. Include the token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

## 🚀 **Endpoints**

### **AI Chat Endpoint**

#### **POST** `/ai/chat`
Send a message to the healthcare AI assistant.

**Request Body:**
```json
{
  "message": "I need help with my Medicaid renewal",
  "memberId": "MEM_123456789",
  "scenario": "redetermination",
  "sessionId": "SESSION_abc123"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "response": "I'll help you with your Medicaid renewal. Let me check your current status and identify any missing requirements...",
    "scenario": "redetermination",
    "confidence": 0.95,
    "followUpRequired": false,
    "tokensUsed": 245,
    "processingTime": 1.2
  }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Invalid request format",
  "details": "Message field is required"
}
```

### **Member Eligibility**

#### **GET** `/members/{memberId}/eligibility`
Check member eligibility and benefits.

**Path Parameters:**
- `memberId` (string): Unique member identifier

**Response:**
```json
{
  "success": true,
  "data": {
    "memberId": "MEM_123456789",
    "isActive": true,
    "planType": "Medicaid Managed Care",
    "effectiveDate": "2024-01-01",
    "expirationDate": "2024-12-31",
    "copayAmount": 0.00,
    "lastUpdated": "2024-01-15T10:30:00Z"
  }
}
```

### **Provider Search**

#### **GET** `/providers`
Search for healthcare providers in the network.

**Query Parameters:**
- `specialty` (string): Medical specialty (e.g., "family medicine")
- `language` (string): Language preference (e.g., "Spanish")
- `location` (string): ZIP code or location
- `radius` (integer): Search radius in miles (default: 10)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "npi": "1234567890",
      "name": "Dr. Maria Gonzalez",
      "specialty": "Family Medicine",
      "languages": ["English", "Spanish"],
      "address": {
        "street": "123 Bronx Ave",
        "city": "Bronx",
        "state": "NY",
        "zip": "10451"
      },
      "phone": "(718) 555-0123",
      "isAccepting": true,
      "distance": 2.3
    }
  ]
}
```

### **Claims Status**

#### **GET** `/claims/{claimNumber}/status`
Check the status of a healthcare claim.

**Path Parameters:**
- `claimNumber` (string): Claim number

**Response:**
```json
{
  "success": true,
  "data": {
    "claimNumber": "CLM_2024_001234",
    "status": "processed",
    "amount": 1250.00,
    "dateSubmitted": "2024-01-10",
    "dateProcessed": "2024-01-12",
    "paymentAmount": 1187.50,
    "deductible": 62.50
  }
}
```

### **Pharmacy Benefits**

#### **GET** `/pharmacy/check`
Check medication coverage and benefits.

**Query Parameters:**
- `medication` (string): Medication name
- `memberId` (string): Member identifier
- `quantity` (integer): Prescription quantity
- `daysSupply` (integer): Days supply

**Response:**
```json
{
  "success": true,
  "data": {
    "medication": "Metformin 500mg",
    "isCovered": true,
    "copayAmount": 3.00,
    "priorAuthRequired": false,
    "quantityLimit": 60,
    "genericAvailable": true,
    "alternativeMedications": [
      {
        "name": "Metformin ER 500mg",
        "isCovered": true,
        "copayAmount": 3.00
      }
    ]
  }
}
```

### **Prior Authorization**

#### **POST** `/pharmacy/prior-auth`
Submit a prior authorization request.

**Request Body:**
```json
{
  "medication": "Ozempic",
  "memberId": "MEM_123456789",
  "prescriberNPI": "1234567890",
  "quantity": 1,
  "daysSupply": 30,
  "diagnosisCode": "E11.9",
  "clinicalNotes": "Patient has tried metformin without adequate glycemic control"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "requestId": "PA_2024_001234",
    "status": "submitted",
    "estimatedDecisionDate": "2024-01-18",
    "urgent": false,
    "supportingDocumentationRequired": false
  }
}
```

### **Analytics & Reporting**

#### **GET** `/analytics`
Get usage analytics and performance metrics.

**Query Parameters:**
- `days` (integer): Number of days to analyze (default: 30)
- `scenario` (string): Filter by specific scenario
- `memberId` (string): Filter by specific member

**Response:**
```json
{
  "success": true,
  "data": {
    "period": "30 days",
    "totalConversations": 15420,
    "averageResolutionTime": 4.2,
    "successRate": 0.94,
    "scenarioBreakdown": {
      "billing": 4520,
      "redetermination": 3890,
      "pharmacy": 3210,
      "provider": 3800
    },
    "costSavings": {
      "estimatedTotal": 456780.50,
      "perConversation": 29.62
    },
    "satisfactionScore": 4.6
  }
}
```

### **Conversation History**

#### **GET** `/conversations/{memberId}`
Get conversation history for a member.

**Path Parameters:**
- `memberId` (string): Member identifier

**Query Parameters:**
- `limit` (integer): Number of conversations to return (default: 10)
- `scenario` (string): Filter by scenario

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 12345,
      "sessionId": "SESSION_abc123",
      "scenario": "redetermination",
      "userMessage": "I need help with my Medicaid renewal",
      "aiResponse": "I'll help you with your Medicaid renewal...",
      "resolved": true,
      "createdAt": "2024-01-15T10:30:00Z",
      "duration": 180
    }
  ]
}
```

## 🔧 **WebSocket Events**

For real-time updates, connect to the WebSocket endpoint:
```
wss://bs734nbc735og.ok.kimi.link/ws
```

### **Events:**

#### **Subscribe to Member Updates**
```json
{
  "type": "subscribe_to_updates",
  "memberId": "MEM_123456789"
}
```

#### **Receive Status Updates**
```json
{
  "type": "member_status_update",
  "memberId": "MEM_123456789",
  "status": "eligibility_changed",
  "data": {
    "isActive": true,
    "planType": "Medicaid Managed Care"
  }
}
```

## 🚨 **Error Handling**

### **Standard Error Response**
```json
{
  "success": false,
  "error": "Invalid request format",
  "details": "Message field is required",
  "timestamp": "2024-01-15T10:30:00Z",
  "requestId": "REQ_abc123"
}
```

### **Error Codes**
- `400`: Bad Request - Invalid input format
- `401`: Unauthorized - Missing or invalid authentication
- `403`: Forbidden - Insufficient permissions
- `404`: Not Found - Resource not found
- `429`: Too Many Requests - Rate limit exceeded
- `500`: Internal Server Error - Server error
- `503`: Service Unavailable - Service temporarily unavailable

## 📊 **Rate Limiting**

- **Standard endpoints**: 100 requests per 15 minutes per IP
- **AI chat endpoint**: 50 requests per 15 minutes per user
- **Authentication endpoints**: 10 requests per 15 minutes per IP

Rate limit headers are included in all responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1642248000
```

## 🔒 **Security**

### **Authentication**
- JWT tokens with 1-hour expiration
- Refresh tokens with 7-day expiration
- Secure HTTP-only cookies

### **Data Protection**
- All data encrypted in transit (TLS 1.3)
- Database encryption at rest
- Input validation and sanitization
- SQL injection prevention
- XSS protection

### **Compliance**
- HIPAA-compliant data handling
- Audit logging for all interactions
- Data retention policies
- Secure API key management

## 🧪 **Testing**

### **Test Environment**
```
https://staging.bs734nbc735og.ok.kimi.link/api
```

### **Test Data**
- **Test Member ID**: `MEM_TEST_123`
- **Test Claim Number**: `CLM_TEST_001`
- **Test Provider NPI**: `1234567890`

## 📚 **SDKs & Libraries**

### **JavaScript/Node.js**
```javascript
const HealthcareAI = require('fidelis-healthcare-ai-sdk');

const client = new HealthcareAI({
  apiKey: 'your-api-key',
  baseURL: 'https://bs734nbc735og.ok.kimi.link/api'
});

const response = await client.ai.chat({
  message: 'I need help with my Medicaid renewal',
  memberId: 'MEM_123456789'
});
```

### **Python**
```python
import fidelis_healthcare_ai

client = fidelis_healthcare_ai.Client(
    api_key='your-api-key',
    base_url='https://bs734nbc735og.ok.kimi.link/api'
)

response = client.ai.chat(
    message='I need help with my Medicaid renewal',
    member_id='MEM_123456789'
)
```

## 📞 **Support**

For API support or questions:
- Email: support@fidelis-healthcare-ai.com
- Documentation: https://bs734nbc735og.ok.kimi.link/docs
- Status Page: https://bs734nbc735og.ok.kimi.link/status

## 🔄 **API Versioning**

Current version: **v1.0.0**

Breaking changes will be announced 30 days in advance. New versions will be released with backward compatibility when possible.

---

**Base URL**: `https://bs734nbc735og.ok.kimi.link/api`  
**Documentation**: `https://bs734nbc735og.ok.kimi.link/docs`  
**Status**: `https://bs734nbc735og.ok.kimi.link/status`