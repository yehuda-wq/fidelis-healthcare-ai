# Contributing to Fidelis Healthcare AI Navigator

Thank you for your interest in contributing to the Fidelis Healthcare AI Navigator! This document provides guidelines and instructions for contributing to the project.

## 🎯 **Getting Started**

### **Prerequisites**
- Node.js 18.x or higher
- PostgreSQL 14.x or higher
- Redis (optional, for caching)
- Git
- Code editor (VS Code recommended)

### **Development Environment Setup**

1. **Fork the Repository**
   ```bash
   # Fork the repository on GitHub, then clone your fork
   git clone https://github.com/yourusername/fidelis-healthcare-ai.git
   cd fidelis-healthcare-ai
   ```

2. **Add Upstream Remote**
   ```bash
   git remote add upstream https://github.com/original-owner/fidelis-healthcare-ai.git
   ```

3. **Install Dependencies**
   ```bash
   npm install
   ```

4. **Setup Environment**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

5. **Start Development Server**
   ```bash
   npm run dev
   ```

## 🏗️ **Development Workflow**

### **Branch Naming Convention**
- `feature/feature-name` - New features
- `bugfix/bug-description` - Bug fixes
- `improvement/improvement-name` - Improvements
- `docs/documentation-update` - Documentation updates

### **Making Changes**

1. **Create a Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make Your Changes**
   - Write clean, documented code
   - Follow the existing code style
   - Add tests for new functionality

3. **Test Your Changes**
   ```bash
   # Run tests
   npm test
   
   # Run linting
   npm run lint
   
   # Check code style
   npm run style-check
   ```

4. **Commit Your Changes**
   ```bash
   git add .
   git commit -m "feat: add new healthcare scenario detection"
   ```

### **Commit Message Format**
Follow conventional commits:
- `feat:` - New features
- `fix:` - Bug fixes
- `docs:` - Documentation changes
- `style:` - Code style changes
- `refactor:` - Code refactoring
- `test:` - Test additions/changes
- `chore:` - Build process or auxiliary tool changes

### **Pull Request Process**

1. **Push to Your Fork**
   ```bash
   git push origin feature/your-feature-name
   ```

2. **Create Pull Request**
   - Use descriptive title and description
   - Reference any related issues
   - Include screenshots for UI changes
   - Ensure all tests pass

3. **Address Review Feedback**
   - Make requested changes
   - Push additional commits
   - Resolve conversations

4. **Merge**
   - Squash commits if requested
   - Delete feature branch after merge

## 📝 **Code Guidelines**

### **JavaScript Style Guide**
- Use ES6+ features
- Follow Airbnb JavaScript Style Guide
- Use async/await for asynchronous operations
- Use meaningful variable and function names
- Add JSDoc comments for functions

**Example:**
```javascript
/**
 * Process healthcare AI conversation
 * @param {string} message - User message
 * @param {string} memberId - Member identifier
 * @param {string} scenario - Healthcare scenario
 * @returns {Promise<Object>} AI response object
 */
async function processHealthcareMessage(message, memberId, scenario) {
    try {
        // Implementation here
        return response;
    } catch (error) {
        logger.error('Processing error:', error);
        throw new Error('Failed to process message');
    }
}
```

### **Database Guidelines**
- Use migrations for schema changes
- Follow naming conventions (snake_case)
- Add indexes for frequently queried columns
- Use transactions for data integrity

**Example:**
```sql
-- Good
CREATE TABLE ai_conversations (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    member_id VARCHAR(50),
    user_message TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ai_conversations_member_id ON ai_conversations(member_id);
CREATE INDEX idx_ai_conversations_created_at ON ai_conversations(created_at);
```

### **API Guidelines**
- Follow RESTful principles
- Use proper HTTP status codes
- Implement rate limiting
- Add comprehensive error handling
- Document all endpoints

**Example:**
```javascript
app.post('/api/ai/chat', async (req, res) => {
    try {
        const { message, memberId, scenario } = req.body;
        
        // Validation
        if (!message) {
            return res.status(400).json({
                success: false,
                error: 'Message is required'
            });
        }
        
        // Process message
        const response = await aiService.processMessage(message, memberId, scenario);
        
        res.json({
            success: true,
            data: response
        });
        
    } catch (error) {
        logger.error('Chat API error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
```

## 🧪 **Testing Guidelines**

### **Test Structure**
```
tests/
├── unit/
│   ├── services/
│   ├── routes/
│   └── models/
├── integration/
│   ├── api/
│   └── workflows/
└── fixtures/
    ├── members.json
    ├── providers.json
    └── conversations.json
```

### **Writing Tests**
**Unit Test Example:**
```javascript
describe('HealthcareAIService', () => {
    describe('processMessage', () => {
        it('should process billing message correctly', async () => {
            const message = 'I have a duplicate billing charge';
            const memberId = 'MEM_TEST_123';
            
            const result = await aiService.processMessage(message, memberId);
            
            expect(result.scenario).toBe('billing');
            expect(result.response).toContain('duplicate');
            expect(result.confidence).toBeGreaterThan(0.8);
        });
    });
});
```

**Integration Test Example:**
```javascript
describe('AI Chat API', () => {
    it('should return AI response for valid request', async () => {
        const response = await request(app)
            .post('/api/ai/chat')
            .send({
                message: 'I need help with my Medicaid renewal',
                memberId: 'MEM_TEST_123'
            });
        
        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.data.response).toBeDefined();
    });
});
```

### **Running Tests**
```bash
# Run all tests
npm test

# Run unit tests only
npm run test:unit

# Run integration tests only
npm run test:integration

# Run tests with coverage
npm run test:coverage

# Run tests in watch mode
npm run test:watch
```

## 🎨 **UI/UX Guidelines**

### **Design Principles**
- Mobile-first responsive design
- Accessibility (WCAG 2.1 AA compliance)
- Healthcare-appropriate color scheme
- Clear information hierarchy
- Fast loading times

### **Component Guidelines**
- Reusable components
- Consistent styling
- Proper error states
- Loading indicators
- Accessibility attributes

**Example:**
```html
<div class="healthcare-card" role="region" aria-label="Healthcare service card">
    <h3 class="card-title">Duplicate Billing Detection</h3>
    <p class="card-description">AI identifies duplicate charges in seconds</p>
    <div class="card-metrics">
        <span class="metric-value">$1,400</span>
        <span class="metric-label">Average savings</span>
    </div>
    <button class="btn-primary" aria-label="Learn more about duplicate billing detection">
        Learn More
    </button>
</div>
```

## 🔒 **Security Guidelines**

### **Data Protection**
- Never commit API keys or secrets
- Use environment variables for sensitive data
- Implement proper input validation
- Use parameterized queries for database operations

### **Authentication & Authorization**
- Implement JWT tokens with proper expiration
- Use refresh tokens for long-lived sessions
- Implement role-based access control
- Log all authentication attempts

### **Healthcare Data Handling**
- Never store PHI (Protected Health Information)
- Anonymize all conversation data
- Implement audit logging
- Follow HIPAA compliance guidelines

## 📚 **Documentation Guidelines**

### **Code Documentation**
- Add JSDoc comments for all functions
- Document API endpoints with examples
- Update README for new features
- Keep documentation up to date

### **API Documentation**
- Use Swagger/OpenAPI specification
- Provide request/response examples
- Document error codes and handling
- Include rate limiting information

## 🚀 **Performance Guidelines**

### **Backend Optimization**
- Use database indexes for queries
- Implement caching with Redis
- Optimize API response times
- Use connection pooling

### **Frontend Optimization**
- Minimize bundle size
- Use lazy loading for images
- Implement service workers
- Optimize for mobile devices

## 🌐 **Deployment Guidelines**

### **Environment Configuration**
- Use separate configs for dev/staging/prod
- Implement proper logging
- Set up monitoring and alerts
- Use CI/CD pipelines

### **Production Checklist**
- [ ] Environment variables configured
- [ ] Database migrations run
- [ ] SSL certificates installed
- [ ] Monitoring setup
- [ ] Backup procedures in place
- [ ] Security scanning completed

## 📋 **Pull Request Checklist**

Before submitting a pull request, ensure:

- [ ] Code follows style guidelines
- [ ] Tests are added and passing
- [ ] Documentation is updated
- [ ] No sensitive data is exposed
- [ ] Performance impact is considered
- [ ] Security implications are reviewed
- [ ] Accessibility requirements are met

## 🤝 **Community Guidelines**

### **Code of Conduct**
- Be respectful and inclusive
- Provide constructive feedback
- Help others learn and grow
- Follow ethical guidelines

### **Communication**
- Use clear, professional language
- Provide detailed issue descriptions
- Be patient with responses
- Help maintain a positive environment

## 📞 **Getting Help**

If you need help:
1. Check existing documentation
2. Search closed issues
3. Ask in community discussions
4. Create a new issue with details

## 🏆 **Recognition**

Contributors will be recognized in:
- README contributors section
- Release notes
- Project documentation
- Special mentions for significant contributions

---

**Thank you for contributing to better healthcare through AI!** 🏥🤖

By following these guidelines, you help ensure the Fidelis Healthcare AI Navigator remains a high-quality, secure, and effective tool for improving healthcare experiences.